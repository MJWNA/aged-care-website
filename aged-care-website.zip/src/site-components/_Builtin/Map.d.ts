declare global {
    interface Window {
        google: {
            maps: any;
        };
    }
}
export declare const MapWidget: any;
