export const baseUrl = import.meta.env.BASE_URL.replace(/\/$/, '');
